class Human(object):
    # Constructor
    def __init__(self, name, hand, legs, mouth=1):
        print("Im in init method")
        self.name1 = name
        self.legs1 = legs
        self.hands1 = hand
        self.mouth1 = mouth
    # Distructor
    def __del__(self):
        print("{} is dead".format(self.name1))
        del self.name1
        del self.hands1

    def disply_human(self):
        print("Name is : {}".format(self.name1))
        print("Legs {}".format(self.legs1))
        print("Hands {}".format(self.hands1))
        print("Mouth {}".format(self.mouth1))

    def walk(self):
        print ("{} is walking".format(self.name1))

    def talk(self):
        print("{} is talking".format(self.name1))

    def clap(self):
        print("{} is clapping".format(self.name1))


jhon_o = Human("Jhon",10,2,2)   # Initilization is called implicite
jhon_o.disply_human()
jhon_o.walk()
jhon_o.talk()
jhon_o.clap()
jhon_o.walk()

print("=======================")
joe = Human("Joe",1,1,2)
joe.disply_human()
joe.walk()
joe.talk()
joe.clap()

