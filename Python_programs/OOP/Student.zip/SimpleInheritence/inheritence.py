class Human(object):
    # Constructor
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def disply_human(self):
        print("Name is : {}".format(self.name))
        print("Age {}".format(self.age))


class Student(Human):

    def __init__(self, name, age,total, avg):
        Human.__init__(self,name, age)
        self.total =total
        self.avg = avg

    def display(self):
        print("Name:{}".format(self.name))
        print("Age:{}".format(self.age))
        print("Total:{}".format(self.total))
        print("Average:{}".format(self.avg))

s = Student("Jhon", 23,500,56)
s.display()
print(s.name)
s.disply_human()

